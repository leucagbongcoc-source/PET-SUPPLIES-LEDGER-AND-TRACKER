package main;

import gui.MainFrame;


public class Main 
{
    public static void main(String[] args) 
    {
        MainFrame frame = new MainFrame();
        
        frame.setVisible(true);
        
        
        
    }
}
